// Configuration: Change this to match your target website
const TARGET_SITE = 'blog.hubspot.com';
// Target selector for the content to copy
const TARGET_SELECTOR = '#hs_cos_wrapper_post_body';

// Get DOM elements
const copyButton = document.getElementById('copyButton');
const messageDiv = document.getElementById('message');

/**
 * Shows a message to the user
 * @param {string} text - Message text
 * @param {string} type - 'success' or 'error'
 */
function showMessage(text, type) {
  messageDiv.textContent = text;
  messageDiv.className = type;
  setTimeout(() => {
    messageDiv.className = '';
    messageDiv.style.display = 'none';
  }, 3000);
}

/**
 * Checks if a URL matches the target site
 * @param {string} url - URL to check
 * @returns {boolean} - True if URL matches target site
 */
function matchesTargetSite(url) {
  try {
    const urlObj = new URL(url);
    return urlObj.hostname === TARGET_SITE || urlObj.hostname.endsWith('.' + TARGET_SITE);
  } catch (e) {
    return false;
  }
}

/**
 * Main function to copy rich HTML content to clipboard
 * Uses Clipboard API first (modern, reliable), falls back to execCommand for compatibility
 */
async function copyPageBody() {
  try {
    // Disable button during operation
    copyButton.disabled = true;
    copyButton.textContent = 'Copying...';

    // Get the active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab) {
      showMessage('Error: No active tab found', 'error');
      copyButton.disabled = false;
      copyButton.textContent = 'Copy page body';
      return;
    }

    // Check if URL matches target site
    if (!matchesTargetSite(tab.url)) {
      showMessage(`Error: This page is not on ${TARGET_SITE}`, 'error');
      copyButton.disabled = false;
      copyButton.textContent = 'Copy page body';
      return;
    }

    // Execute script to clone and process the target element with images inlined
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: async () => {
        // Find the target element
        const targetElement = document.querySelector('#hs_cos_wrapper_post_body');
        if (!targetElement) {
          return { error: 'Target element not found' };
        }

        // Clone the element to avoid modifying the original
        const clone = targetElement.cloneNode(true);

        // Process all images in the clone
        const images = clone.querySelectorAll('img');
        const imagePromises = Array.from(images).map(async (img) => {
          const src = img.src || img.getAttribute('src');
          if (!src) return;

          try {
            // Skip data URLs and blob URLs (already inlined)
            if (src.startsWith('data:') || src.startsWith('blob:')) {
              return;
            }

            // Fetch the image as a blob
            // Note: This may fail due to CORS restrictions on cross-origin images
            const response = await fetch(src);
            if (!response.ok) {
              console.warn(`Failed to fetch image: ${src}`);
              return;
            }

            const blob = await response.blob();
            
            // Convert blob to data URL
            return new Promise((resolve) => {
              const reader = new FileReader();
              reader.onloadend = () => {
                img.src = reader.result;
                resolve();
              };
              reader.onerror = () => {
                console.warn(`Failed to convert image to data URL: ${src}`);
                resolve();
              };
              reader.readAsDataURL(blob);
            });
          } catch (error) {
            // CORS or other fetch errors - image will remain as original URL
            // This is a known limitation: cross-origin images cannot be inlined
            console.warn(`Could not inline image ${src}:`, error.message);
          }
        });

        // Wait for all images to be processed (or fail gracefully)
        await Promise.all(imagePromises);

        // Serialize the cloned DOM to HTML string
        const htmlContent = clone.outerHTML;

        return { html: htmlContent };
      }
    });

    const result = results[0]?.result;

    if (!result || result.error) {
      showMessage(result?.error || 'Error: Could not find post body content', 'error');
      copyButton.disabled = false;
      copyButton.textContent = 'Copy page body';
      return;
    }

    const htmlContent = result.html;

    if (!htmlContent || htmlContent.trim().length === 0) {
      showMessage('Error: No content to copy', 'error');
      copyButton.disabled = false;
      copyButton.textContent = 'Copy page body';
      return;
    }

    // Attempt to copy using modern Clipboard API with HTML format
    // This is preferred because it preserves formatting and allows pasting as rich HTML
    try {
      const clipboardItem = new ClipboardItem({
        'text/html': new Blob([htmlContent], { type: 'text/html' })
      });
      await navigator.clipboard.write([clipboardItem]);
      showMessage('Success! Rich content copied to clipboard', 'success');
    } catch (clipboardError) {
      // Fallback: Use execCommand for older browsers or when Clipboard API fails
      // This requires creating a temporary contentEditable div to preserve HTML formatting
      console.warn('Clipboard API failed, using fallback:', clipboardError);
      
      // Create a temporary contentEditable div to hold the HTML
      const tempDiv = document.createElement('div');
      tempDiv.contentEditable = true;
      tempDiv.innerHTML = htmlContent;
      tempDiv.style.position = 'fixed';
      tempDiv.style.left = '-9999px';
      document.body.appendChild(tempDiv);
      
      // Select all content in the div
      const range = document.createRange();
      range.selectNodeContents(tempDiv);
      const selection = window.getSelection();
      selection.removeAllRanges();
      selection.addRange(range);
      
      try {
        const success = document.execCommand('copy');
        selection.removeAllRanges();
        if (success) {
          showMessage('Success! Content copied to clipboard (fallback method)', 'success');
        } else {
          throw new Error('execCommand copy failed');
        }
      } catch (execError) {
        throw new Error('Both clipboard methods failed');
      } finally {
        document.body.removeChild(tempDiv);
      }
    }
    
  } catch (error) {
    console.error('Error copying page body:', error);
    showMessage(`Error: ${error.message}`, 'error');
  } finally {
    // Re-enable button
    copyButton.disabled = false;
    copyButton.textContent = 'Copy page body';
  }
}

// Attach click event listener to the button
copyButton.addEventListener('click', copyPageBody);
